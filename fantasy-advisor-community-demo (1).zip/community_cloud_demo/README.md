# Fantasy Advisor sample demo

This archive contains only the `community_cloud_demo/` folder. Extract it into the root of the existing project; it will not overwrite the main `app.py` or `requirements.txt`.

The preview uses fictional NBA and NFL data. It does not collect cookies, connect to ESPN, Sleeper, or Yahoo, make network calls, or offer live fantasy advice. Do not add credentials to the demo.

## Run in Visual Studio Code

From the project root, run:

```bash
python -m streamlit run community_cloud_demo/app.py
```

The existing project requirements already include Streamlit and pandas.

## Publish on Streamlit Community Cloud

Select `community_cloud_demo/app.py` as the app entry point in the existing GitHub repository. The demo needs no secrets or database configuration. Review the app's access settings before sharing its URL.

The full app is not included here. Its multi-user storage, provider connections, and isolation checks remain separate work.
